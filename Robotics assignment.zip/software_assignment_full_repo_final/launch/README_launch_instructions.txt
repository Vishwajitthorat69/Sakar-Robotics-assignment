Use spawn_robot.launch.py with argument arm:=A or arm:=B
